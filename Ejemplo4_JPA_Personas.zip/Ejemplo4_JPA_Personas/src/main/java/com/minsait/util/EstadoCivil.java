package com.minsait.util;

public enum EstadoCivil {
	
	SOLTERO, CASADO, VIUDO, DIVORCIADO, PAREJA_HECHO;

}
