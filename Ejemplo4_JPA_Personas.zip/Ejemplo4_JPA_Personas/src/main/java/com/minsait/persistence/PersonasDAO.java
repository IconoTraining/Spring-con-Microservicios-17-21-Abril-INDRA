package com.minsait.persistence;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "personas", path = "personas")
public interface PersonasDAO extends CrudRepository<Persona, Long>{
	
	// Mostrar todas las personas
	// http://localhost:8080/personas
	
	// Buscar una persona por su id
	// http://localhost:8080/personas/2

}
