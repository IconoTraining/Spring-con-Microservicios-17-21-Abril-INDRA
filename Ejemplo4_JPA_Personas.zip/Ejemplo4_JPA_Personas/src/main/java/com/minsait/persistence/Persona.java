package com.minsait.persistence;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.minsait.util.EstadoCivil;

@Entity
@Table(name = "personas")
@SecondaryTable(name = "curriculums",
		pkJoinColumns = {@PrimaryKeyJoinColumn(name="ID_PERSONA", referencedColumnName = "ID")})
public class Persona implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8152779780514975782L;
	
	@Id // Primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY)   // Genera automaticamente de forma autoincremental
	private Long ID;
	
	@Column(name = "NOMBRE", nullable = false)
	private String nombre;
	
	@Column(name = "APELLIDO")
	private String apellido;
	
	@Column(name = "SEXO", length = 1)
	private char sexo;
	
	@Column(name = "EDAD")
	private int edad;
	
	@Column(name = "ESTADO_CIVIL")
	@Enumerated(value = EnumType.STRING)
	private EstadoCivil estadoCivil;
	
	@Column(name = "FECHA_NACIMIENTO")
	@Temporal(value = TemporalType.DATE)
	private Date fechaNacimiento;
	
	@Column(name = "CURRICULUM_VITAE", table = "curriculums")
	@Lob
	@Basic(fetch = FetchType.LAZY)   // carga vaga
	private String curriculum;
	
	public Persona() {
	}

	public Persona(String nombre, String apellido, char sexo, int edad, EstadoCivil estadoCivil, Date fechaNacimiento,
			String curriculum) {
		super();
		this.nombre = nombre;
		this.apellido = apellido;
		this.sexo = sexo;
		this.edad = edad;
		this.estadoCivil = estadoCivil;
		this.fechaNacimiento = fechaNacimiento;
		this.curriculum = curriculum;
	}

	public Long getID() {
		return ID;
	}

	public void setID(Long iD) {
		ID = iD;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public char getSexo() {
		return sexo;
	}

	public void setSexo(char sexo) {
		this.sexo = sexo;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public EstadoCivil getEstadoCivil() {
		return estadoCivil;
	}

	public void setEstadoCivil(EstadoCivil estadoCivil) {
		this.estadoCivil = estadoCivil;
	}

	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public String getCurriculum() {
		return curriculum;
	}

	public void setCurriculum(String curriculum) {
		this.curriculum = curriculum;
	}

	@Override
	public String toString() {
		return "Persona [ID=" + ID + ", nombre=" + nombre + ", apellido=" + apellido + ", sexo=" + sexo + ", edad="
				+ edad + ", estadoCivil=" + estadoCivil + ", fechaNacimiento=" + fechaNacimiento + ", curriculum="
				+ curriculum + "]";
	}
	
	

}
