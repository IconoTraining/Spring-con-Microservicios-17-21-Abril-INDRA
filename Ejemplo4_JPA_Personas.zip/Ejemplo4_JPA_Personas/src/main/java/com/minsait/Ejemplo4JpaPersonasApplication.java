package com.minsait;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.minsait.persistence.Persona;
import com.minsait.persistence.PersonasDAO;
import com.minsait.util.EstadoCivil;

@SpringBootApplication
public class Ejemplo4JpaPersonasApplication implements CommandLineRunner{
	
	@Autowired
	private PersonasDAO dao;

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo4JpaPersonasApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		dao.save(new Persona("Felipe", "Torres", 'H', 37, EstadoCivil.CASADO, 
				new Date(1985, 11, 23), "Abogado. Lincenciado en la Universidad Complutense de Madrid"));
		dao.save(new Persona("Maria", "Lopez", 'M', 42, EstadoCivil.DIVORCIADO, 
				new Date(1982, 9, 14), "Enfermera. Lincenciada en la Universidad Carlos III de Madrid"));
	}

}
