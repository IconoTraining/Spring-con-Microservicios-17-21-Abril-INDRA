package com.minsait;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.minsait.persistence.Persona;
import com.minsait.persistence.PersonasDAO;
import com.minsait.util.EstadoCivil;

@SpringBootApplication
public class Ejemplo4JpaPersonasApplication implements CommandLineRunner{
	
	@Autowired
	private PersonasDAO dao;

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo4JpaPersonasApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		dao.save(new Persona("Felipe", "Torres", 'H', 37, EstadoCivil.CASADO, 
				new Date(1985, 11, 23), "Abogado. Lincenciado en la Universidad Complutense de Madrid"));
		dao.save(new Persona("Maria", "Lopez", 'M', 42, EstadoCivil.DIVORCIADO, 
				new Date(1982, 9, 14), "Enfermera. Lincenciada en la Universidad Carlos III de Madrid"));
		dao.save(new Persona("Juan", "Arias", 'H', 25, EstadoCivil.CASADO, 
				new Date(1998, 5, 20), "Periodista. Lincenciado en la Universidad Complutense de Madrid"));
		dao.save(new Persona("Antonia", "Sanchez", 'M', 56, EstadoCivil.DIVORCIADO, 
				new Date(1967, 4, 18), "Informatica. Lincenciada en la Universidad Politecnica de Madrid"));
		
		// Mostrar los mayores de 50 años
		for(Persona p: dao.findByEdadGreaterThan(50)) {
			System.out.println(p);
		}
		
		// Mostrar el total de personas en la BBDD
		System.out.println("Tengo " + dao.count() + " registros en mi tabla");
	}

}
