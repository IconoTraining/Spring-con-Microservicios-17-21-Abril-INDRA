package com.minsait.clients;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.minsait.models.Producto;

// Este cliente siempre lanza la peticion a la instancia 
// desplegada en el puerto 8001, esta demasiado acoplado
// @FeignClient(name = "servicio-productos", url = "localhost:8001")
@FeignClient(name = "servicio-productos")
public interface ProductoClienteRest {
	
	@GetMapping("/listar")
	public List<Producto> listar();
	
	@GetMapping("/buscar/{id}")
	public Producto buscar(@PathVariable Long id);

}
