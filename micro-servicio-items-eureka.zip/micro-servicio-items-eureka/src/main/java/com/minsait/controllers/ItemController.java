package com.minsait.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.minsait.models.Item;
import com.minsait.services.ItemService;

@RestController
public class ItemController {
	
	@Autowired
	// Otra forma de resolver ambigüedades es poner el nombre del bean a inyectar
	//@Qualifier("serviceFeign")
	@Qualifier("serviceRestTemplate")
	private ItemService itemService;
	
	
	// http://localhost:8002/listar
	@GetMapping("/listar")
	public List<Item> listar(){
		return itemService.consultarTodos();
	}
	
	
	// http://localhost:8002/ver/2/cantidad/5
	@GetMapping("/ver/{id}/cantidad/{cantidad}")
	public Item agregar(@PathVariable Long id, @PathVariable Integer cantidad) {
		return itemService.buscarItem(id, cantidad);
	}

}
