package com.minsait.services;

import java.util.List;

import com.minsait.models.Item;

public interface ItemService {
	
	List<Item> consultarTodos();
	Item buscarItem(Long id, Integer cantidad);
	

}
