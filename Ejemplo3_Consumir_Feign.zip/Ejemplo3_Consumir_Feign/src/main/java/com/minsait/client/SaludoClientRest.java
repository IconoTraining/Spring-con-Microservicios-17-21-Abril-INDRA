package com.minsait.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name="servicio", url = "localhost:8080")
public interface SaludoClientRest {
	
	@RequestMapping("/saludo")
	public String saludar();
	
	@RequestMapping("/despedida")
	public String despedir(@RequestParam(value="name")  String nombre);

}
