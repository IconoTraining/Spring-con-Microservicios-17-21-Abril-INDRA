package com.minsait;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;

import com.minsait.client.SaludoClientRest;

@SpringBootApplication
@EnableFeignClients
public class Ejemplo3ConsumirFeignApplication {
	
	@Autowired
	private SaludoClientRest clienteFeign;
	
	@Bean
	public CommandLineRunner run() {
		return datos -> {
			String mensaje = clienteFeign.saludar();
			System.out.println(mensaje);
		};
	}

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo3ConsumirFeignApplication.class, args);
	}

}
