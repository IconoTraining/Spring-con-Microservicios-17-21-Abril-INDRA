package com.minsait.services;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SaludoRest {
	
	// http://localhost:8080/saludo
	@RequestMapping("/saludo")
	public String saludar() {
		return "Bienvenidos al curso de microservicios";
	}
	
	
	// http://localhost:8080/despedida?name=Anabel
	@RequestMapping("/despedida")
	public String despedir(@RequestParam(value = "name") String nombre) {
		return "Hasta luego " + nombre + "!!!";
	}

}
