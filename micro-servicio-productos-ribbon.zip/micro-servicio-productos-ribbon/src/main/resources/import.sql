-- obligatoriamente este archivo se tiene que llamar import.sql
insert into productos (descripcion, precio) values ('Monitor', 129.50);
insert into productos (descripcion, precio) values ('Teclado', 50.89);
insert into productos (descripcion, precio) values ('Raton', 25.95);
insert into productos (descripcion, precio) values ('Sacnner', 230);
insert into productos (descripcion, precio) values ('Pizarra digital', 500);