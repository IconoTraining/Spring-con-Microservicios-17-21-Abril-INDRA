package com.minsait.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.minsait.models.Item;
import com.minsait.models.Producto;
import com.minsait.services.ItemService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
public class ItemController {
	
	@Autowired
	// Otra forma de resolver ambigüedades es poner el nombre del bean a inyectar
	//@Qualifier("serviceFeign")
	@Qualifier("serviceRestTemplate")
	private ItemService itemService;
	
	
	// http://localhost:8002/listar
	@GetMapping("/listar")
	public List<Item> listar(){
		return itemService.consultarTodos();
	}
	
	
	// http://localhost:8002/ver/2/cantidad/5
	@GetMapping("/ver/{id}/cantidad/{cantidad}")
	// En el caso de recibir una excepcion llamas al metodo manejarError
	@HystrixCommand(fallbackMethod = "manejarError")
	public Item agregar(@PathVariable Long id, @PathVariable Integer cantidad) {
		return itemService.buscarItem(id, cantidad);
	}
	
	
	public Item manejarError(Long id, Integer cantidad, Throwable ex) {	
		// class com.netflix.hystrix.exception.HystrixTimeoutException
		System.err.println(ex.getClass()+ "*****************");
		System.err.println(ex.getMessage() + "-----------------------------");
		
		Producto producto = new Producto();
		producto.setID(id);
		producto.setDescripcion("Producto vacio");
		producto.setPrecio(0);
		
		Item item = new Item(producto, cantidad);
		
		return item;
	}

}
