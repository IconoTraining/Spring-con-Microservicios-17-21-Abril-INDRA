package com.minsait.services;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GradosRest {
	
	// localhost:8080/fahrenheit/35
	@RequestMapping("/fahrenheit/{grados}")
	public double gradosAFahrenheit(@PathVariable double grados) {
		return (grados * 9/5) + 32;
	}
	
	// localhost:8080/grados/95
	@RequestMapping("/grados/{fahrenheit}")
	public double fahrenheitAGrados(@PathVariable double fahrenheit) {
		return (fahrenheit - 32) * 5/9;
	}

}
