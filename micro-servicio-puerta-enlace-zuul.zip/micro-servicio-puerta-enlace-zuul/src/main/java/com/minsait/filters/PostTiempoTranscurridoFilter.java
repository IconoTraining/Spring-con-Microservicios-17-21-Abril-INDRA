package com.minsait.filters;

import org.springframework.stereotype.Component;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

@Component
public class PostTiempoTranscurridoFilter extends ZuulFilter{

	@Override
	public boolean shouldFilter() {
		// Habilitar o deshabilitar el filtro
		// Si devuelve true se ejecuta el metodo run()
		// Si devuelve false no se ejecuta
		return true;
	}

	@Override
	public Object run() throws ZuulException {
		// Aqui se resuelve la logica de negocio
		// Aqui mediremos el tiempo final de la peticion
		
		// Tomar el tiempo final
		Long tiempoFinal = System.currentTimeMillis();
		
		// Lo recupero del atributo de peticion
		RequestContext ctx = RequestContext.getCurrentContext();
		long tiempoInicio =  (long) ctx.getRequest().getAttribute("tiempoInicio");
			
		// Mostrar en consola la diferencia de tiempos
		System.out.println("***********************************************");
		System.out.println("Tiempo transcurrido: " + (tiempoFinal - tiempoInicio) + " mseg.");
		System.out.println("***********************************************");
		
		return null;
	}

	@Override
	public String filterType() {
		// Hay 3 tipos de filtro: pre, post, route
		// 	* pre: se ejecuta antes de que se request sea enrutado. 
		//         Se usa para pasar datos al request.
		//  * post: se ejecuta despues del request.
		//          Se usa para modificar la respuesta
		//	* route: se ejecuta duantante el enrutado de request, aqui se resuelve la ruta.
		//           Se usa para la comunicacion con el microservicio
		
		return "post";
	}

	@Override
	public int filterOrder() {
		// Si hay varios filtros elegimos el orden de ejecución
		return 0;
	}

}
