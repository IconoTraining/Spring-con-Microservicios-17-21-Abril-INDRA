package com.minsait.persistence;

import java.io.Serializable;

import org.springframework.data.annotation.Id;

import com.minsait.models.Direccion;

public class Cliente implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5513227620572556346L;

	@Id
	private String id;   // El id debe ser de tipo String
	
	private String nombre;
	private String cif;
	private double cifraVentas;
	private boolean vip;
	private Direccion direccion;
	
	
	public Cliente() {
		// TODO Auto-generated constructor stub
	}


	public Cliente(String nombre, String cif, double cifraVentas, boolean vip, Direccion direccion) {
		super();
		this.nombre = nombre;
		this.cif = cif;
		this.cifraVentas = cifraVentas;
		this.vip = vip;
		this.direccion = direccion;
	}


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getCif() {
		return cif;
	}


	public void setCif(String cif) {
		this.cif = cif;
	}


	public double getCifraVentas() {
		return cifraVentas;
	}


	public void setCifraVentas(double cifraVentas) {
		this.cifraVentas = cifraVentas;
	}


	public boolean isVip() {
		return vip;
	}


	public void setVip(boolean vip) {
		this.vip = vip;
	}


	public Direccion getDireccion() {
		return direccion;
	}


	public void setDireccion(Direccion direccion) {
		this.direccion = direccion;
	}


	@Override
	public String toString() {
		return "Cliente [id=" + id + ", nombre=" + nombre + ", cif=" + cif + ", cifraVentas=" + cifraVentas + ", vip="
				+ vip + ", direccion=" + direccion + "]";
	}
	
	

}
