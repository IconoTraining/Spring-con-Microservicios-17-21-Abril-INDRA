package com.minsait.persistence;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "clientes", path = "clientes")
public interface ClientesDAO extends MongoRepository<Cliente, String>{
	
	// Mostrar todos los clientes
	// http://localhost:8080/clientes
	
	// Buscar por id
	// http://localhost:8080/clientes/643e5893700c5c0f336fa67f
	
	// Metodos heredados de MongoRepository
	// https://docs.spring.io/spring-data/jpa/docs/current/reference/html/
		
	// Podemos crear nuestros metodos personalizados utilizando palabras clave
	// https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#repository-query-keywords
	
	// Para ver en el navegador los metodos creados:
	// http://localhost:8080/clientes/search
	
	// http://localhost:8080/clientes/search/findByVip?vip=true
	public List<Cliente> findByVip(@Param("vip") boolean vip);
	
	// http://localhost:8080/clientes/search/findByDireccion_Poblacion?poblacion=Madrid
	public List<Cliente> findByDireccion_Poblacion(@Param("poblacion") String poblacion);

}
