package com.minsait;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.minsait.models.Direccion;
import com.minsait.persistence.Cliente;
import com.minsait.persistence.ClientesDAO;

@SpringBootApplication
public class Ejemplo5MongoDbClientesApplication implements CommandLineRunner{
	
	@Autowired
	private ClientesDAO dao;
	
	@Override
	public void run(String... args) throws Exception {
		
		// Borrar todos los datos
		dao.deleteAll();
		
		// Alta de clientes
		dao.save(new Cliente("Transportes Lopez", "1111111-A", 50000, false, new Direccion("Mayor", 28, "Madrid")));
		dao.save(new Cliente("Fruteria Antonio", "2222222-B", 150000, true, new Direccion("Diagonal", 80, "Barcelona")));
		dao.save(new Cliente("Peluqueria Mary", "3333333-C", 800000, true, new Direccion("Real", 56, "Valencia")));
		dao.save(new Cliente("Limpiezas Juan", "4444444-D", 10000, false, new Direccion("Recoletos", 35, "Sevilla")));
		
	}

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo5MongoDbClientesApplication.class, args);
	}

}
