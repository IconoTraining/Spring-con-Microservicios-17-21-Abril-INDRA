package com.minsait;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejemplo5MongoDbClientesApplicationTests {

	@Test
	void contextLoads() {
	}

}
