package com.minsait.persistence;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "alumnos")
public class Alumno implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6566597708563993595L;

	@Id
	private Long ID;

	@Column(name = "NOMBRE", nullable = false)
	private String nombre;

	@Column(name = "APELLIDO")
	private String apellido;

	@Column(name = "NOTA")
	private double nota;

	public Alumno() {
		// TODO Auto-generated constructor stub
	}

	public Alumno(Long iD, String nombre, String apellido, double nota) {
		super();
		ID = iD;
		this.nombre = nombre;
		this.apellido = apellido;
		this.nota = nota;
	}

	public Long getID() {
		return ID;
	}

	public void setID(Long iD) {
		ID = iD;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public double getNota() {
		return nota;
	}

	public void setNota(double nota) {
		this.nota = nota;
	}

	@Override
	public String toString() {
		return "Alumno [ID=" + ID + ", nombre=" + nombre + ", apellido=" + apellido + ", nota=" + nota + "]";
	}

}
