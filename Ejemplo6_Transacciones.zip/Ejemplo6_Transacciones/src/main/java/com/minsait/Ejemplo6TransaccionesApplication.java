package com.minsait;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.minsait.persistence.Alumno;
import com.minsait.persistence.AlumnosDAO;

@SpringBootApplication
public class Ejemplo6TransaccionesApplication implements CommandLineRunner{
	
	@Autowired
	private AlumnosDAO dao;
	
	@Override
	public void run(String... args) throws Exception {
		List<Alumno> lista = new ArrayList<>();
		lista.add(new Alumno(1L, "Maria", "Lopez", 9.2));
		lista.add(new Alumno(2L, "Juan", "Gutierrez", 5.8));
		lista.add(new Alumno(3L, "Elena", "Rodriguez", 6.3));
		
		// Esto no es un error de clave duplicada, ya que save (crea o modifica)
		lista.add(new Alumno(2L, "Juan", "Gutierrez", 6.8));
		
		// Una entidad vacia si provoca error. 
		// Tiene PK null y ademas el nombre tampoco puede ser null
		lista.add(new Alumno());
		
		try {
			insertar(lista);
		} catch (Exception e) {
			System.out.println("Ha ocurrido un error ");
		}
		
	}
	
	@Transactional(propagation = Propagation.REQUIRED,
				   isolation = Isolation.SERIALIZABLE,
				   rollbackFor = Exception.class)
	public void insertar(List<Alumno> alumnos) {
		/*
		for (Alumno alumno : alumnos) {
			// El metodo save trata cada insercción como una transaccion independiente
			dao.save(alumno);
		}
		*/
		
		
		// Con saveAll solo hay una transaccion y si falla no creara ningun registro
		dao.saveAll(alumnos);
	}
	

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo6TransaccionesApplication.class, args);
	}

}
