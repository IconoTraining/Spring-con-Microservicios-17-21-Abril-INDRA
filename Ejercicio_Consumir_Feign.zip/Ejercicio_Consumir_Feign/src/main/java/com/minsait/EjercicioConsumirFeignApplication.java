package com.minsait;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;

import com.minsait.client.GradosClientRest;

@SpringBootApplication
@EnableFeignClients
public class EjercicioConsumirFeignApplication {
	
	@Autowired
	private GradosClientRest clienteFeign;
	
	@Bean
	public CommandLineRunner run() {
		return datos -> {
			System.out.println(clienteFeign.gradosAFahrenheit(35) 
					+ " grados Fahrenheit");
			System.out.println(clienteFeign.fahrenheitAGrados(95) 
					+ " grados Celsius");
		};
	}

	public static void main(String[] args) {
		SpringApplication.run(EjercicioConsumirFeignApplication.class, args);
	}

}
