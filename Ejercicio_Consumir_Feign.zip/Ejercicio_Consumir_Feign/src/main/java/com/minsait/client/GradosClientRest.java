package com.minsait.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "servicio", url = "localhost:8080")
public interface GradosClientRest {
	
	@GetMapping("/fahrenheit/{grados}")
	public double gradosAFahrenheit(@PathVariable double grados);
	
	@GetMapping("/grados/{fahrenheit}")
	public double fahrenheitAGrados(@PathVariable double fahrenheit);

}
