package com.minsait;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class EjercicioConsumirRestTemplateApplication {
	
	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}
	
	@Bean
	public CommandLineRunner run(RestTemplate restTemplate) {
		return datos -> {
			double fahrenheit = restTemplate.getForObject(
					"http://localhost:8080/fahrenheit/35", Double.class);
			System.out.println(fahrenheit + " Grados fahrenheit");
			double grados = restTemplate.getForObject(
					"http://localhost:8080/grados/95", Double.class);
			System.out.println(grados + " Grados celsius");
		};
	}

	public static void main(String[] args) {
		SpringApplication.run(EjercicioConsumirRestTemplateApplication.class, args);
	}

}
