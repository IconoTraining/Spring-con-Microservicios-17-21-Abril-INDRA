package com.minsait.clients;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.minsait.models.Item;

@FeignClient(name = "servicio-items")
public interface ItemClientRest {

	
	@GetMapping("/listar")
	public List<Item> listar();
	
	
	@GetMapping("/ver/{id}/cantidad/{cantidad}")
	public Item agregar(@PathVariable Long id, @PathVariable Integer cantidad);
}
