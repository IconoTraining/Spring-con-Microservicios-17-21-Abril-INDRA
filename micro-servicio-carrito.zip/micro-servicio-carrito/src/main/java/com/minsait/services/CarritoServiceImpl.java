package com.minsait.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.minsait.clients.ItemClientRest;
import com.minsait.models.Carrito;
import com.minsait.models.Item;
import com.minsait.persistence.CarritoDAO;

@Service
public class CarritoServiceImpl implements CarritoService {
	
	@Autowired
	private CarritoDAO dao;
	
	@Autowired
	private ItemClientRest clienteFeign;
	
	

	@Override
	public Carrito crear(String usuario) {
		return dao.save(new Carrito(usuario, new ArrayList<>(), 0));
	}

	@Override
	public void agregarItem(Long id, Integer cantidad, String usuario) {
		Carrito carrito = buscar(usuario);
		Item item = clienteFeign.agregar(id, cantidad);
		carrito.getContenido().add(item);
		carrito.setImporte(carrito.getImporte() + (item.getProducto().getPrecio() * cantidad));
		
		
		// faltaba guardarlo en el carrito
		dao.save(carrito);
	}

	@Override
	public Carrito buscar(String usuario) {
		return dao.findByUsuario(usuario);
	}

	@Override
	public void eliminarItem(Long id, String usuario) {
		Carrito carrito = buscar(usuario);
		List<Item> contenido = carrito.getContenido();
		Item encontrado = null;
		for (Item item : contenido) {
			if (id == item.getProducto().getID()) {
				encontrado = item;
				break;
			}
		}
		contenido.remove(encontrado);
		carrito.setImporte(carrito.getImporte() - 
				(encontrado.getProducto().getPrecio() * encontrado.getCantidad()));
		
		dao.save(carrito);
		
	}

}
















