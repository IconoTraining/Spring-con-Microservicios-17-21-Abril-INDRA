package com.minsait.services;

import com.minsait.models.Carrito;

public interface CarritoService {
	
	Carrito crear(String usuario);
	void agregarItem(Long id, Integer cantidad, String usuario);
	Carrito buscar(String usuario);

}
