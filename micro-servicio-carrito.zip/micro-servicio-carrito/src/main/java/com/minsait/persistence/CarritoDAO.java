package com.minsait.persistence;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.minsait.models.Carrito;

@RepositoryRestResource(collectionResourceRel = "carritos", path = "carritos")
public interface CarritoDAO extends MongoRepository<Carrito, String>{
	
	
	public Carrito findByUsuario(@Param("usuario") String usuario);
	
	

}
