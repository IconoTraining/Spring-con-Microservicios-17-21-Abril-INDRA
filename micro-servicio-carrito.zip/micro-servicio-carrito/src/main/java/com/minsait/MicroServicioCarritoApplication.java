package com.minsait;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

import com.minsait.persistence.CarritoDAO;

@SpringBootApplication
@EnableFeignClients
@EnableEurekaClient
public class MicroServicioCarritoApplication implements CommandLineRunner{

	@Autowired
	private CarritoDAO dao;

	@Override
	public void run(String... args) throws Exception {
		
		// Elimanos todos los datos
		//dao.deleteAll();
		
	}
	
	public static void main(String[] args) {
		SpringApplication.run(MicroServicioCarritoApplication.class, args);
	}

}
