package com.minsait.services;

import java.util.List;

import com.minsait.models.entity.Producto;

public interface IProductoService {
	
	List<Producto> consultarTodos();
	Producto buscarProducto(Long id);

}
